import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

export const mailSender = async (email, name) => {
    const transporter = nodemailer.createTransport({
        service: "gmail",
        secure: true,
        auth: {
            user: process.env.EMAIL_SENDER,
            pass: process.env.EMAIL_SENDER_PASSWORD
        },
        tls: {
            rejectUnauthorized: false,
        },
    });

    const mailOptions = {
        from: process.env.EMAIL_SENDER,
        to: email,
        subject: "Welcome to Finance Tracker!",
        text: `Dear ${name},

Welcome to Finance Tracker! 

Best Regards,
The Finance Tracker Team`
    };

    try {
        const response = await transporter.sendMail(mailOptions);
        console.log("Email sent:", response.envelope);
    } catch (error) {
        console.error("Error sending email:", error);
    }
};
