import Admin from "../models/admin";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const adminLogin = async (req, res) => {
    const { email, password } = req.body;

    try {
        const admin = await Admin.findOne({ email });

        if (!admin || !(await bcrypt.compare(password, admin.password))) {
            return res.status(401).json({ success: false, message: "Invalid email or password" });
        }

        // Generate JWT token
        const token = jwt.sign({ id: admin._id, email: admin.email }, process.env.ADMIN_AUTH_SECRET, { expiresIn: "7d" });

        res.json({ success: true, token, admin: { email: admin.email, id: admin._id } });
    } catch (error) {
        res.status(500).json({ success: false, message: "Server error", error });
    }
};
